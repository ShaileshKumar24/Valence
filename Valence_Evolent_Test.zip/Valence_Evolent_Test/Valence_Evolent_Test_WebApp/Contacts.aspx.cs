﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using ValenceEvolentTest.Models;
using System.Net.Http;
using System.Text;

namespace Valence_Evolent_Test_WebApp
{
    public partial class Contacts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!(IsPostBack))
            {
                BindContacts();                
            }
        }

        /// <summary>
        /// Clearing The Input Fields.
        /// </summary>
        private void ClearControls()
        {
            hdnContactID.Value = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPhoneNumber.Text = string.Empty;
            chkStatus.Checked = false;
        }

        /// <summary>
        /// Binding Contacts to Grid.
        /// </summary>
        private void BindContacts()
        {
            List<ContactInfo> lstContacts = callAPI<ContactInfo>("ValenceEvolentTest", "GetAllContacts", "GET");

            gvContacts.DataSource = lstContacts;
            gvContacts.DataBind();
        }

        /// <summary>
        /// Binding Contact Information to Input Fields.
        /// </summary>
        /// <param name="contactID"></param>
        private void BindContact(string contactID)
        {
            List<ContactInfo> lstContacts = callAPI<ContactInfo>("ValenceEvolentTest", "GetContact", "GET", contactID);

            if (lstContacts.Count >= 0)
            {
                hdnContactID.Value = Convert.ToString(lstContacts[0].ContactID);

                txtFirstName.Text = lstContacts[0].FirstName;
                txtLastName.Text = lstContacts[0].LastName;
                txtEmail.Text = lstContacts[0].Email;
                txtPhoneNumber.Text = lstContacts[0].PhoneNumber;
                chkStatus.Checked = lstContacts[0].Status;
            }
        }

        /// <summary>
        /// Adding / Updating Contact.
        /// </summary>
        private void AddUpdateContact()
        {
            ContactInfo contactInfo = GetContactInfo();

            if (contactInfo.ContactID > 0){ // Update Contact.
                callAPI<ContactInfo>("ValenceEvolentTest", "PutContact", "PUT", Newtonsoft.Json.JsonConvert.SerializeObject(contactInfo));
            }
            else{ // Adding New Contact.
                callAPI<ContactInfo>("ValenceEvolentTest", "PostContact", "POST", Newtonsoft.Json.JsonConvert.SerializeObject(contactInfo));
            }
            ClearControls();
            BindContacts();            
            
            DisplayMessage("Contact Added/Updated Successfully.", System.Drawing.Color.Green);
        }

        /// <summary>
        /// Deleting Contact.
        /// </summary>
        /// <param name="contactID"></param>
        private void DeleteContact(string contactID)
        {
            callAPI<ContactInfo>("ValenceEvolentTest", "DeleteContact", "DELETE", contactID);
        }

        /// <summary>
        /// Retrieving the Values From Input Field
        /// </summary>
        /// <returns></returns>
        private ContactInfo GetContactInfo()
        {
            ContactInfo contactInfo = new ContactInfo();

            if (hdnContactID.Value != string.Empty) { 
                contactInfo.ContactID = Convert.ToInt32(hdnContactID.Value);
            }

            contactInfo.FirstName = txtFirstName.Text.Trim();
            contactInfo.LastName = txtLastName.Text.Trim();
            contactInfo.Email = txtEmail.Text.Trim();
            contactInfo.PhoneNumber = txtPhoneNumber.Text.Trim();
            contactInfo.Status = chkStatus.Checked;

            return (contactInfo);
        }

        /// <summary>
        /// Retrieving The Grid Data Key Value.
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        private string GetContactID(object sender){
            LinkButton btn = sender as LinkButton;
            GridViewRow row = btn.NamingContainer as GridViewRow;
            return (gvContacts.DataKeys[row.RowIndex].Values[0].ToString());
        }

        /// <summary>
        /// Displaying Message For CRUD Operations.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="color"></param>
        private void DisplayMessage(string message, System.Drawing.Color color)
        {
            lblMessage.Text = message;
            lblMessage.Visible = true;
            lblMessage.ForeColor = color;
        }

        /// <summary>
        /// Calling Web API Service.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="controllerName"></param>
        /// <param name="methodName"></param>
        /// <param name="verb"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private List<T> callAPI<T>(string controllerName, string methodName, string verb, string parameters = "")
        {
            try
            {
                using (var client = new System.Net.Http.HttpClient())
                {
                    client.BaseAddress = new Uri(ConfigurationManager.AppSettings["webAPI"]);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    
                    //var response = client.GetAsync(string.Join("/", controllerName, methodName, parameters)).Result;

                    HttpContent content;
                    HttpResponseMessage response = null;

                    switch (verb)
                    {
                        case "GET":
                            response = client.GetAsync(string.Join("/", controllerName, methodName, parameters)).Result;
                            break;
                        case "POST":
                            content = new StringContent(parameters, Encoding.UTF8, "application/json");
                            response = client.PostAsync(string.Join("/", controllerName, methodName), content).Result;
                            break;
                        case "PUT":
                            content = new StringContent(parameters, Encoding.UTF8, "application/json");
                            response = client.PutAsync(string.Join("/", controllerName, methodName), content).Result;
                            break;
                        case "DELETE":
                            response = client.DeleteAsync(string.Join("/", controllerName, methodName, parameters)).Result;
                            break;
                    }

                    if (response.IsSuccessStatusCode)
                    {
                        string responseString = response.Content.ReadAsStringAsync().Result;
                        //Newtonsoft.Json.Linq.JObject json = Newtonsoft.Json.Linq.JObject.Parse(responseString);
                        //Newtonsoft.Json.Linq.JObject json = Newtonsoft.Json.Linq.JObject.Parse(responseString.TrimStart(new char[] { '[' }).TrimEnd(new char[] { ']' }));
                        if (responseString != string.Empty){
                            return (Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(responseString).ToList());
                        }
                        else { return null; }
                    }else
                    {                        
                        DisplayMessage("There is an Exception", System.Drawing.Color.Red);
                        return null;
                    }
                }
            }
            catch (Exception ex) {
                DisplayMessage("There is an Exception", System.Drawing.Color.Red);
                throw ex; 
            }
        }

        /// <summary>
        /// Grid View Page Index Changing Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvContacts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvContacts.PageIndex = e.NewPageIndex;
            BindContacts();
        }

        /// <summary>
        /// Grid View Column Sorting Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvContacts_OnSorting(object sender, GridViewSortEventArgs e)
        {
            //gvContacts.Sort(e.SortExpression, e.SortDirection);
            //BindContacts();
        }

        /// <summary>
        /// Grid View Edit Button Click Event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            //LinkButton btn = sender as LinkButton;
            //GridViewRow row = btn.NamingContainer as GridViewRow;
            //string pk = gvContacts.DataKeys[row.RowIndex].Values[0].ToString();
            BindContact(GetContactID(sender));
        }
        
        /// <summary>
        /// Grid View Delete Button Click Event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            DeleteContact(GetContactID(sender));
            ClearControls();
            BindContacts();

            DisplayMessage("Contact Deleted Successfully.", System.Drawing.Color.Green);            
        }

        /// <summary>
        /// Adding/Updating Contact
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnContact_Click(object sender, EventArgs e)
        {
            AddUpdateContact();
        }
        
        /// <summary>
        /// Cancel Button Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControls();
        }
    }
}
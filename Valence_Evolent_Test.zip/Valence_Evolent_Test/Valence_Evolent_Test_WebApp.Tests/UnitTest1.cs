﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Valence_Evolent_Test_WebApp.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}

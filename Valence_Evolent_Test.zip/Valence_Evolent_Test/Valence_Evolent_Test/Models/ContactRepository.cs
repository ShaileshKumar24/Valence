﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;

namespace ValenceEvolentTest.Models
{
    public class ContactRepository : IContactRepository
    { 
        private List<ContactInfo> Contacts = new List<ContactInfo>();         

        static public String ConnectionString
        {
            get
            {    // get connection string with name  database from  web.config.
                return WebConfigurationManager.ConnectionStrings["ValenceConnectionString"].ConnectionString;
            }
        }
 
        public ContactRepository() 
        {            
        }

        public IEnumerable<ContactInfo> GetAllContacts() 
        {
            var sqlConnection = new SqlConnection(ConnectionString);

            //string query1 = string.Format("INSERT INTO [dbo].[VE_tbD_Contacts] ([FirstName], [LastName], [Email], [PhoneNumber], [Status]) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')", "Test", "Test", "Test", "Test", Convert.ToString(true));
            
            try { 
                DataTable data = new DataTable();                
                using (var sqlCommand = new SqlCommand("SELECT * FROM [dbo].[VE_tbD_Contacts]", sqlConnection))
                using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                {
                    sqlDataAdapter.Fill(data);
                }

                Contacts = (from DataRow row in data.Rows
                            select new ContactInfo
                            {
                                ContactID = Convert.ToInt32(row["ContactID"]),
                                FirstName = row["FirstName"].ToString(),
                                LastName = row["LastName"].ToString(),
                                Email = row["Email"].ToString(),
                                PhoneNumber = row["PhoneNumber"].ToString(),
                                Status = Convert.ToBoolean(row["Status"])
                            }).ToList();                

                return Contacts;
            }
            catch (Exception ex) {
                sqlConnection.Close();
                sqlConnection.Dispose();
                throw ex; 
            }
        }

        public ContactInfo Get(int id) 
        {
            var sqlConnection = new SqlConnection(ConnectionString);
            ContactInfo contactInfo = new ContactInfo();

            try
            {
                SqlDataReader sqlDataReader;
                string query = string.Format("SELECT * FROM [dbo].[VE_tbD_Contacts] WHERE ContactID = {0}", id.ToString());
                
                using (var sqlCommand = new SqlCommand(query, sqlConnection))                
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlConnection.Open();
                    sqlDataReader = sqlCommand.ExecuteReader(CommandBehavior.CloseConnection);

                    while (sqlDataReader.Read())
                    {
                        contactInfo.ContactID = Convert.ToInt32(sqlDataReader["ContactID"]);
                        contactInfo.FirstName = sqlDataReader["FirstName"].ToString();
                        contactInfo.LastName = sqlDataReader["LastName"].ToString();
                        contactInfo.Email = sqlDataReader["Email"].ToString();
                        contactInfo.PhoneNumber = sqlDataReader["PhoneNumber"].ToString();
                        contactInfo.Status = Convert.ToBoolean(sqlDataReader["Status"]);
                    }

                    sqlDataReader.Close();
                    sqlConnection.Close();
                }

                return contactInfo;
            }
            catch (Exception ex)
            {
                sqlConnection.Close();
                sqlConnection.Dispose();
                throw ex;
            }            
        }

        public ContactInfo Add(ContactInfo contactInfo) 
        {
            var sqlConnection = new SqlConnection(ConnectionString);

            try
            {
                string query = string.Format("INSERT INTO [dbo].[VE_tbD_Contacts] ([FirstName], [LastName], [Email], [PhoneNumber], [Status]) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')", contactInfo.FirstName, contactInfo.LastName, contactInfo.Email, contactInfo.PhoneNumber, Convert.ToString(contactInfo.Status));

                using (var sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();                    
                    sqlConnection.Close();
                }

                return contactInfo;
            }
            catch (Exception ex)
            {
                sqlConnection.Close();
                sqlConnection.Dispose();
                throw ex;
            }            
        } 
 
        public void Remove(int id) 
        {
            var sqlConnection = new SqlConnection(ConnectionString);

            try
            {
                string query = string.Format("DELETE FROM [dbo].[VE_tbD_Contacts] WHERE ContactID = '{0}'", id);

                using (var sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();
                }                
            }
            catch (Exception ex)
            {
                sqlConnection.Close();
                sqlConnection.Dispose();
                throw ex;
            }            
        }

        public bool Update(ContactInfo contactInfo) 
        {
            var sqlConnection = new SqlConnection(ConnectionString);

            try
            {
                string query = string.Format("UPDATE [dbo].[VE_tbD_Contacts] SET [FirstName] = '{0}', [LastName] = '{1}', [Email] = '{2}', [PhoneNumber] = '{3}', [Status] = '{4}' WHERE ContactID = '{5}'", contactInfo.FirstName, contactInfo.LastName, contactInfo.Email, contactInfo.PhoneNumber, Convert.ToString(contactInfo.Status), contactInfo.ContactID);

                using (var sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();
                }

                return true;
            }
            catch (Exception ex)
            {
                sqlConnection.Close();
                sqlConnection.Dispose();
                throw ex;
            }            
        } 
    } 
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace ValenceEvolentTest.Models
{
    public class ContactRepository : IContactRepository
    { 
        private List<ContactInfo> Contacts = new List<ContactInfo>(); 
        //private int _nextId = 1; 
 
        public ContactRepository() 
        {
            Add(new ContactInfo {  ContactID = 1, FirstName = "Shailesh", LastName = "Kumar", Email = "shailesh@gmail.com", PhoneNumber = "12345678", Status = true});
            Add(new ContactInfo { ContactID = 2, FirstName = "Prashant", LastName = "More", Email = "prashant@gmail.com", PhoneNumber = "12345678", Status = true });
            Add(new ContactInfo { ContactID = 3, FirstName = "Nilesh", LastName = "Patil", Email = "nilesh@gmail.com", PhoneNumber = "12345678", Status = true });
            Add(new ContactInfo { ContactID = 4, FirstName = "Mahesh", LastName = "Wagh", Email = "mahesh@gmail.com", PhoneNumber = "12345678", Status = true });
        }

        public IEnumerable<ContactInfo> GetAllContacts() 
        { 
            return Contacts; 
        }

        public ContactInfo Get(int id) 
        {
            return Contacts.Find(s => s.ContactID == id);
        }

        public ContactInfo Add(ContactInfo contactInfo) 
        {
            if (contactInfo == null) 
            { 
                throw new ArgumentNullException("item"); 
            }
            Contacts.Add(contactInfo);
            return contactInfo; 
        } 
 
        public void Remove(int id) 
        {
            Contacts.RemoveAll(s => s.ContactID == id); 
        }

        public bool Update(ContactInfo contactInfo) 
        {
            if (contactInfo == null) 
            { 
                throw new ArgumentNullException("Contact"); 
            }
            int index = Contacts.FindIndex(s => s.ContactID == contactInfo.ContactID); 
            if (index == -1) 
            { 
                return false; 
            }
            Contacts.RemoveAt(index);
            Contacts.Add(contactInfo); 
            return true; 
        } 
    } 
}
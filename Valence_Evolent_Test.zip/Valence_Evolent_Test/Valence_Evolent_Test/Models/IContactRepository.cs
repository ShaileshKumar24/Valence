﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ValenceEvolentTest.Models
{
    //public class IContactRepository
    //{
        public interface IContactRepository
        {
            IEnumerable<ContactInfo> GetAllContacts();
            ContactInfo Get(int id);
            ContactInfo Add(ContactInfo contactInfo);
            void Remove(int contactID);
            bool Update(ContactInfo contactInfo);
        } 
    //}
}
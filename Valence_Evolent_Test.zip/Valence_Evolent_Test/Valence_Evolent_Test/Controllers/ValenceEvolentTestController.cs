﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ValenceEvolentTest.Models;

namespace ValenceEvolentTest.Controllers
{
    [ContactExceptionFilter]
    public class ContactController : ApiController
    {
        IContactRepository contactRepository = new ContactRepository();        

        //Retrieving All Contacts.        
        public IEnumerable<ContactInfo> GetAllContacts()
        {            
            return contactRepository.GetAllContacts();
        }

        //Retrieving Contact By ContactID.
        public HttpResponseMessage GetContact(int id)
        {
            ContactInfo contactInfo = contactRepository.Get(id);            

            if (contactInfo == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Contact Not found for the Given ID");
            }else{
                //return Request.CreateResponse(HttpStatusCode.OK, contactInfo);
                return Request.CreateResponse(HttpStatusCode.OK, new List<ContactInfo>() { contactInfo });
            }
        }

        //Adding a New Contact.
        public HttpResponseMessage PostContact(ContactInfo contactInfo)
        {
            contactInfo = contactRepository.Add(contactInfo);
            //var response = Request.CreateResponse<ContactInfo>(HttpStatusCode.Created, contactInfo);
            var response = Request.CreateResponse(HttpStatusCode.Created, new List<ContactInfo>() { contactInfo });
            
            return response;
        }

        //Updating an Existing Contact By ContactID.
        public HttpResponseMessage PutContact(ContactInfo contactInfo)
        {
            //contactInfo.ContactID = id;
            if (!contactRepository.Update(contactInfo))
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Unable to Update the Contact for the Given ID");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.OK);
            }
        }

        //Deleting a Contact By ContactID.
        public HttpResponseMessage DeleteContact(int id)
        {
            contactRepository.Remove(id);
            return new HttpResponseMessage(HttpStatusCode.NoContent);            
        }        
    }
}
